#!/bin/bash
#install ansible 
#install install epel-release a requirement for ansible
echo "****** Installing Ansible and requirements ******"
sudo yum install epel-release -y 
#install ansible
sudo yum install ansible -y 