#!/bin/bash
#install git client to be able to clone repositories
echo "****** Installing Git ******"
sudo yum install git -y 