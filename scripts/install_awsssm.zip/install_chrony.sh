#!/bin/bash
#add required utilities
#install and configure chrony
echo "****** Installing Chrony ******"
sudo yum install chrony  -y