#!/bin/bash
#add required utilities
#add the radius disabled group for freeradius
sudo groupadd radius-disabled
