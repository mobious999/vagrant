#!/bin/bash
#add required utilities
echo "****** Installing Dns Utilities ******"
sudo yum install bind-utils -y