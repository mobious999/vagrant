#!/bin/bash
#update all software#
echo "****** Installing Unzip ******"
sudo yum -y update
