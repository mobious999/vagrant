#!/bin/bash
#install Apache for the linotp web interface
echo "****** Installing Apache ******"