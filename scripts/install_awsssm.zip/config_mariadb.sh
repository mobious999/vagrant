#!/bin/bash
#add required utilities
#utility for unpacking zip files
echo "****** Installing Unzip ******"
sudo yum install unzip -y
