#!/bin/bash

echo "****** Setting the system hostame ******"
sudo hostnamectl set-hostname Wellfleet