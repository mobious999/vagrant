#!/bin/bash
#add required utilities
#configure all necessary software#
echo "****** Installing Google Authenticator ******"
sudo yum install pam-devel make gcc-c++ git automake autoconf libtoo -y
