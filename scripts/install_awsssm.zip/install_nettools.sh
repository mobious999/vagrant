#!/bin/bash
#add required utilities
#install net utils
echo "****** Installing Network Utilities ******"
sudo yum install net-tools -y