#!/bin/bash
#add required utilities
#configure all necessary software#
#configure the firewall rules if the firewall is enabled
#sudo firewall-cmd --zone=public --add-port=123/udp
#sudo firewall-cmd -–zone=public -–add-port=1812/udp
#sudo firewall-cmd -–zone=public -–add-port=1813/udp
#sudo firewall-cmd --permanent --zone=public --add-port=123/udp
#sudo firewall-cmd -–permanent --zone=public -–add-port=1812/udp
#sudo firewall-cmd -–permanent --zone=public -–add-port=1813/udp
#firewall-cmd --reload