#!/bin/bash
#install wget
sudo yum install wget -y 